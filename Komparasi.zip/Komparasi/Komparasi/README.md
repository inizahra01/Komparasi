# Aplikasi Komparasi

Aplikasi Android sederhana untuk mengelola data mahasiswa menggunakan Data Binding.

## Deskripsi
Aplikasi ini merupakan contoh implementasi Data Binding di Android yang memungkinkan pengguna untuk menyimpan dan menampilkan data mahasiswa (NIM dan Nama).

## Fitur
- Input data mahasiswa (NIM dan Nama)
- Data Binding untuk manajemen UI
- Toast notification saat data berhasil disimpan

## Teknologi yang Digunakan
- Kotlin
- Android SDK
- View Binding
- Data Binding
- AndroidX
- Material Design Components

## Spesifikasi Teknis
- Minimum SDK: 24 (Android 7.0)
- Target SDK: 35
- Kotlin Version: Menggunakan JVM Target 11
- Build System: Gradle dengan Kotlin DSL

## Cara Menjalankan Aplikasi
1. Clone repositori ini
2. Buka proyek menggunakan Android Studio
3. Tunggu proses sync Gradle selesai
4. Jalankan aplikasi pada emulator atau perangkat Android

## Pengembang
- Nama: Difa Nugraha
- NIM: 10122059
- Kelas: IF-2

## Lisensi
Hak Cipta © 2024 Difa Nugraha. 
