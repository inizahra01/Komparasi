package com.example.komparasi

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.view.View
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.komparasi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    var mahasiswa: Mahasiswa = Mahasiswa()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        binding.btnSimpan.setOnClickListener {
            mahasiswa.nim = binding.edtNim.text.toString()
            mahasiswa.nama = binding.edtNama.text.toString()
            binding.mahasiswa = mahasiswa
            Toast.makeText(this, "Data Berhasil Disimpan", Toast.LENGTH_SHORT).show()
        }

    }
}

/*
Nim : 10122066
Nama : Nurul Fithriani Zahra
Kelas : IF-2
*/