package com.example.komparasi

data class Mahasiswa(
    var nim: String = "",
    var nama: String = ""

)
